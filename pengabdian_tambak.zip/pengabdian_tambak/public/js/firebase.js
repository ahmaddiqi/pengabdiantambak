var firebaseConfig = {
    apiKey: "AIzaSyDS81QcCOxpms6Jnko7NZGgcP2HBs77DlA",
    authDomain: "pengabdian-tambak.firebaseapp.com",
    databaseURL: "https://pengabdian-tambak.firebaseio.com",
    projectId: "pengabdian-tambak",
    storageBucket: "pengabdian-tambak.appspot.com",
    messagingSenderId: "409061593331",
    appId: "1:409061593331:web:d2c1247b2a694a183d2786"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
